# Project Report
## Smart Digital Expense Tracker with Budget Prediction

**Course:** BCA I Semester  
**Session:** 2026–2027  
**Lab Sheet:** 09  
**Programming Language:** C++

## 1. Objective
To develop a smart expense management system that helps users record daily expenses, categorize spending, monitor monthly budgets, and estimate whether the monthly budget may be exceeded.

## 2. Problem Statement
Many students spend money daily but do not track their expenses. This project provides a simple way to record expenses, review spending, and receive a warning when spending approaches or exceeds a set monthly budget.

## 3. Modules
1. User Registration
2. Login System
3. Add Daily Expense
4. View Expense History
5. Category-wise Expense
6. Monthly Expense Report
7. Budget Setting
8. Budget Warning
9. Expense Prediction
10. Search Expense
11. Delete Expense
12. File Saving

## 4. Concepts Used
- Variables and data types
- Conditional statements and loops
- Arrays
- Structures
- Functions
- Strings
- Searching
- File handling
- Menu-driven programming

## 5. Algorithm / Logic
1. Start the program and load previously saved expenses and budget.
2. Display the registration, login, and exit options.
3. Allow a new user to register or an existing user to log in.
4. After successful login, display the main menu.
5. Read the user's menu choice.
6. Add, display, search, delete, or summarize expenses according to the selected option.
7. Save updated expense and budget information in text files.
8. Compare current-month spending with the saved budget and display a warning when needed.
9. Estimate month-end spending using average daily spending.
10. Continue until the user chooses to log out, then end the program.

## 6. Sample Input and Output
Example interaction (illustrative):

```text
====== SMART DIGITAL EXPENSE TRACKER ======
1. Register
2. Login
0. Exit
Enter your choice: 1

--- User Registration ---
Create username: student1
Create password: demo123
Registration successful. You can now log in.

====== SMART DIGITAL EXPENSE TRACKER ======
1. Register
2. Login
0. Exit
Enter your choice: 2

--- Login ---
Username: student1
Password: demo123
Login successful. Welcome, student1!

========== SMART DIGITAL EXPENSE TRACKER ==========
1. Add Daily Expense
2. View Expense History
3. Category-wise Expense
4. Monthly Expense Report
5. Set Monthly Budget
6. Budget Warning
7. Expense Prediction
8. Search Expense
9. Delete Expense
10. Save Data
0. Logout and Exit
```

## 7. Conclusion
The Smart Digital Expense Tracker provides a simple way to record and manage daily expenses. It demonstrates the use of C++ structures, arrays, functions, loops, searching, and file handling. It also helps users monitor a budget through warnings and a basic spending estimate.

## 8. Limitations
- The program is a console-based educational project.
- The prediction uses a simple average-based calculation and is not AI-based.
- User passwords are stored in a local text file for demonstration only.
- The program stores up to 500 expense records in memory at a time.
