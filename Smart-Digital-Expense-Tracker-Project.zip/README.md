# Smart Digital Expense Tracker with Budget Prediction

**Course:** BCA I Semester (Session 2026–2027)  
**Lab Sheet:** 09  
**Language:** C++

## Project objective
To develop a menu-driven expense management program that records daily expenses, organizes spending by category, monitors a monthly budget, and estimates whether the budget may be exceeded.

## Features
1. User registration
2. Login system
3. Add daily expenses
4. View expense history
5. Category-wise expense total
6. Monthly expense report
7. Set a monthly budget
8. Budget warning at 80% and when exceeded
9. Basic month-end expense estimate
10. Search an expense by ID
11. Delete an expense by ID
12. Save records using file handling

## Files
- `main.cpp` — complete C++ source code
- `PROJECT_REPORT.md` — project report
- `README.md` — project overview

The program creates these data files automatically in the folder where it runs:
- `users.txt`
- `expenses.txt`
- `budget.txt`

## How to compile and run
Using a C++ compiler such as g++:

```bash
g++ -std=c++11 main.cpp -o expense_tracker
./expense_tracker
```

On Windows with MinGW:

```bash
g++ -std=c++11 main.cpp -o expense_tracker.exe
expense_tracker.exe
```

## Important notes
- Enter dates in `DD-MM-YYYY` format, for example `03-11-2026`.
- Enter the report month in `MM-YYYY` format, for example `11-2026`.
- The prediction is a simple average-based estimate, not an AI/ML model.
- This is an educational demonstration. The sample login stores passwords in a local text file and is not suitable for real accounts or sensitive information.
- The current version uses a fixed capacity of 500 expense records.
