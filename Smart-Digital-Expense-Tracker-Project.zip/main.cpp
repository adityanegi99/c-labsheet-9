#include <iostream>
#include <fstream>
#include <string>
#include <iomanip>
#include <limits>
#include <ctime>
using namespace std;

// Smart Digital Expense Tracker with Budget Prediction
// BCA I Semester - Lab Sheet 09

struct Expense {
    int id;
    string date;
    string category;
    string description;
    double amount;
};

const int MAX_EXPENSES = 500;
Expense expenses[MAX_EXPENSES];
int expenseCount = 0;
double monthlyBudget = 0.0;
string currentUser;

void checkBudgetWarning();

void clearInput() {
    cin.clear();
    cin.ignore(numeric_limits<streamsize>::max(), '\n');
}

void loadExpenses() {
    expenseCount = 0;
    ifstream file("expenses.txt");
    Expense e;
    while (file >> e.id) {
        file.ignore();
        getline(file, e.date, '|');
        getline(file, e.category, '|');
        getline(file, e.description, '|');
        file >> e.amount;
        file.ignore(numeric_limits<streamsize>::max(), '\n');
        if (expenseCount < MAX_EXPENSES) {
            expenses[expenseCount++] = e;
        }
    }
    file.close();
}

void saveExpenses() {
    ofstream file("expenses.txt");
    for (int i = 0; i < expenseCount; i++) {
        file << expenses[i].id << '\n'
             << expenses[i].date << '|'
             << expenses[i].category << '|'
             << expenses[i].description << '|'
             << expenses[i].amount << '\n';
    }
    file.close();
}

void loadBudget() {
    ifstream file("budget.txt");
    if (file) file >> monthlyBudget;
    file.close();
}

void saveBudget() {
    ofstream file("budget.txt");
    file << monthlyBudget;
    file.close();
}

bool registerUser() {
    string username, password, savedUser, savedPass;
    cout << "\n--- User Registration ---\n";
    cout << "Create username: ";
    cin >> username;
    cout << "Create password: ";
    cin >> password;

    ifstream in("users.txt");
    while (in >> savedUser >> savedPass) {
        if (savedUser == username) {
            cout << "This username already exists.\n";
            in.close();
            return false;
        }
    }
    in.close();

    ofstream out("users.txt", ios::app);
    out << username << " " << password << '\n';
    out.close();
    cout << "Registration successful. You can now log in.\n";
    return true;
}

bool loginUser() {
    string username, password, savedUser, savedPass;
    cout << "\n--- Login ---\n";
    cout << "Username: ";
    cin >> username;
    cout << "Password: ";
    cin >> password;

    ifstream file("users.txt");
    while (file >> savedUser >> savedPass) {
        if (savedUser == username && savedPass == password) {
            currentUser = username;
            file.close();
            cout << "Login successful. Welcome, " << currentUser << "!\n";
            return true;
        }
    }
    file.close();
    cout << "Invalid username or password.\n";
    return false;
}

void addExpense() {
    if (expenseCount >= MAX_EXPENSES) {
        cout << "Expense storage is full.\n";
        return;
    }

    Expense e;
    e.id = 1;
    for (int i = 0; i < expenseCount; i++) {
        if (expenses[i].id >= e.id) e.id = expenses[i].id + 1;
    }

    cout << "\n--- Add Daily Expense ---\n";
    cout << "Enter date (DD-MM-YYYY): ";
    cin >> e.date;
    clearInput();
    cout << "Enter category (Food/Travel/Shopping/Bills/Other): ";
    getline(cin, e.category);
    cout << "Enter description: ";
    getline(cin, e.description);
    cout << "Enter amount: ";
    while (!(cin >> e.amount) || e.amount < 0) {
        cout << "Please enter a valid non-negative amount: ";
        clearInput();
    }

    expenses[expenseCount++] = e;
    saveExpenses();
    cout << "Expense added and saved successfully.\n";
    checkBudgetWarning();
}

void viewExpenses() {
    cout << "\n--- Expense History ---\n";
    if (expenseCount == 0) {
        cout << "No expenses recorded yet.\n";
        return;
    }

    cout << left << setw(6) << "ID" << setw(15) << "Date"
         << setw(16) << "Category" << setw(24) << "Description"
         << right << setw(10) << "Amount\n";
    cout << string(71, '-') << '\n';

    for (int i = 0; i < expenseCount; i++) {
        cout << left << setw(6) << expenses[i].id
             << setw(15) << expenses[i].date
             << setw(16) << expenses[i].category
             << setw(24) << expenses[i].description
             << right << setw(10) << fixed << setprecision(2)
             << expenses[i].amount << '\n';
    }
}

void categoryWiseExpense() {
    string category;
    double total = 0;
    cout << "\nEnter category to calculate (Food/Travel/Shopping/Bills/Other): ";
    clearInput();
    getline(cin, category);

    for (int i = 0; i < expenseCount; i++) {
        if (expenses[i].category == category) total += expenses[i].amount;
    }
    cout << "Total spending in " << category << ": Rs. "
         << fixed << setprecision(2) << total << '\n';
}

void monthlyReport() {
    string month;
    double total = 0;
    cout << "\nEnter month and year (MM-YYYY): ";
    cin >> month;

    cout << "\n--- Monthly Expense Report ---\n";
    for (int i = 0; i < expenseCount; i++) {
        if (expenses[i].date.size() >= 10 &&
            expenses[i].date.substr(3, 7) == month) {
            cout << expenses[i].date << " | " << expenses[i].category
                 << " | " << expenses[i].description << " | Rs. "
                 << fixed << setprecision(2) << expenses[i].amount << '\n';
            total += expenses[i].amount;
        }
    }
    cout << "Total expense for " << month << ": Rs. "
         << fixed << setprecision(2) << total << '\n';
    if (monthlyBudget > 0) {
        cout << "Monthly budget: Rs. " << monthlyBudget << '\n';
        cout << "Remaining budget: Rs. " << monthlyBudget - total << '\n';
    }
}

void setBudget() {
    cout << "\nEnter your monthly budget: Rs. ";
    while (!(cin >> monthlyBudget) || monthlyBudget < 0) {
        cout << "Enter a valid non-negative budget: Rs. ";
        clearInput();
    }
    saveBudget();
    cout << "Monthly budget saved successfully.\n";
    checkBudgetWarning();
}

double calculateCurrentMonthTotal() {
    // Uses the system date only when it is available; otherwise asks user
    // to use the monthly report for a selected month.
    time_t now = time(0);
    tm *local = localtime(&now);
    char monthYear[8];
    strftime(monthYear, sizeof(monthYear), "%m-%Y", local);
    string currentMonth(monthYear);

    double total = 0;
    for (int i = 0; i < expenseCount; i++) {
        if (expenses[i].date.size() >= 10 &&
            expenses[i].date.substr(3, 7) == currentMonth) {
            total += expenses[i].amount;
        }
    }
    return total;
}

void checkBudgetWarning() {
    if (monthlyBudget <= 0) return;
    double total = calculateCurrentMonthTotal();
    cout << "Current month's recorded spending: Rs. "
         << fixed << setprecision(2) << total << '\n';
    if (total > monthlyBudget) {
        cout << "WARNING: You have exceeded your monthly budget!\n";
    } else if (total >= monthlyBudget * 0.80) {
        cout << "Budget alert: You have used at least 80% of your budget.\n";
    } else {
        cout << "You are within your monthly budget.\n";
    }
}

void predictExpense() {
    double total = calculateCurrentMonthTotal();
    time_t now = time(0);
    tm *local = localtime(&now);
    int day = local->tm_mday;
    int daysInMonth = 31;

    // A simple estimate based on average daily spending so far.
    if (day > 0) {
        double predicted = (total / day) * daysInMonth;
        cout << "\n--- Expense Prediction ---\n";
        cout << "Spending recorded this month: Rs. "
             << fixed << setprecision(2) << total << '\n';
        cout << "Estimated spending by month-end: Rs. " << predicted << '\n';
        if (monthlyBudget > 0 && predicted > monthlyBudget) {
            cout << "Prediction: You may exceed your monthly budget.\n";
        } else {
            cout << "Prediction: You may remain within your monthly budget.\n";
        }
        cout << "Note: This is a basic estimate, not an AI prediction.\n";
    }
}

void searchExpense() {
    int id;
    bool found = false;
    cout << "\nEnter expense ID to search: ";
    cin >> id;
    for (int i = 0; i < expenseCount; i++) {
        if (expenses[i].id == id) {
            cout << "Expense found:\n";
            cout << "Date: " << expenses[i].date << '\n'
                 << "Category: " << expenses[i].category << '\n'
                 << "Description: " << expenses[i].description << '\n'
                 << "Amount: Rs. " << expenses[i].amount << '\n';
            found = true;
            break;
        }
    }
    if (!found) cout << "No expense found with this ID.\n";
}

void deleteExpense() {
    int id;
    bool found = false;
    cout << "\nEnter expense ID to delete: ";
    cin >> id;

    for (int i = 0; i < expenseCount; i++) {
        if (expenses[i].id == id) {
            for (int j = i; j < expenseCount - 1; j++) {
                expenses[j] = expenses[j + 1];
            }
            expenseCount--;
            saveExpenses();
            cout << "Expense deleted successfully.\n";
            found = true;
            break;
        }
    }
    if (!found) cout << "No expense found with this ID.\n";
}

void showMenu() {
    int choice;
    do {
        cout << "\n========== SMART DIGITAL EXPENSE TRACKER ==========\n";
        cout << "1. Add Daily Expense\n";
        cout << "2. View Expense History\n";
        cout << "3. Category-wise Expense\n";
        cout << "4. Monthly Expense Report\n";
        cout << "5. Set Monthly Budget\n";
        cout << "6. Budget Warning\n";
        cout << "7. Expense Prediction\n";
        cout << "8. Search Expense\n";
        cout << "9. Delete Expense\n";
        cout << "10. Save Data\n";
        cout << "0. Logout and Exit\n";
        cout << "Enter your choice: ";

        if (!(cin >> choice)) {
            clearInput();
            cout << "Please enter a number.\n";
            continue;
        }

        switch (choice) {
            case 1: addExpense(); break;
            case 2: viewExpenses(); break;
            case 3: categoryWiseExpense(); break;
            case 4: monthlyReport(); break;
            case 5: setBudget(); break;
            case 6: checkBudgetWarning(); break;
            case 7: predictExpense(); break;
            case 8: searchExpense(); break;
            case 9: deleteExpense(); break;
            case 10:
                saveExpenses();
                saveBudget();
                cout << "All data saved successfully.\n";
                break;
            case 0:
                saveExpenses();
                saveBudget();
                cout << "Logged out. Thank you for using the tracker.\n";
                break;
            default: cout << "Invalid choice. Try again.\n";
        }
    } while (choice != 0);
}

int main() {
    loadExpenses();
    loadBudget();

    int choice;
    do {
        cout << "\n====== SMART DIGITAL EXPENSE TRACKER ======\n";
        cout << "1. Register\n";
        cout << "2. Login\n";
        cout << "0. Exit\n";
        cout << "Enter your choice: ";

        if (!(cin >> choice)) {
            clearInput();
            cout << "Please enter a number.\n";
            continue;
        }

        switch (choice) {
            case 1: registerUser(); break;
            case 2:
                if (loginUser()) showMenu();
                break;
            case 0: cout << "Goodbye!\n"; break;
            default: cout << "Invalid choice. Try again.\n";
        }
    } while (choice != 0);

    return 0;
}
